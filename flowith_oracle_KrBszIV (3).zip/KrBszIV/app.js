import { menuData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    renderMenu();
    setupForm();
    setupNavbar();
});

function renderMenu() {
    const container = document.getElementById('menu-container');
    if (!container) return;

    container.innerHTML = menuData.map(item => `
        <div class="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 hover:border-emerald-500/50 transition-colors group flex flex-col h-full">
            <span class="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2">${item.category}</span>
            <h3 class="text-xl font-bold mb-2 group-hover:text-emerald-400 transition-colors">${item.title}</h3>
            <p class="text-zinc-400 text-sm mb-4 flex-grow">${item.description}</p>
            <div class="text-lg font-bold text-white">${item.price}</div>
        </div>
    `).join('');
}

function setupForm() {
    const form = document.getElementById('custom-burger-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const type = document.getElementById('burger-type').value;
        const cook = document.getElementById('cook-level').value;
        const fries = document.getElementById('fries-type').value;
        const drink = document.getElementById('drink-type').value;
        const notes = document.getElementById('special-notes').value;
        
        const extraCheckboxes = form.querySelectorAll('input[type="checkbox"]:checked');
        const extras = Array.from(extraCheckboxes).map(cb => cb.value).join(', ') || 'Ninguno';

        const message = `🔥 *NUEVO PEDIDO PERSONALIZADO* 🔥\n\n` +
                        `*Tipo:* ${type}\n` +
                        `*Término:* ${cook}\n` +
                        `*Extras:* ${extras}\n` +
                        `*Papas:* ${fries}\n` +
                        `*Bebida:* ${drink}\n` +
                        (notes ? `*Notas:* ${notes}\n` : '') +
                        `\n¡Hola Bora Bora! Me gustaría ordenar esta hamburguesa.`;

        const encodedMessage = encodeURIComponent(message);
        const whatsappUrl = `https://wa.me/5218282844323?text=${encodedMessage}`;
        
        window.open(whatsappUrl, '_blank');
    });
}

function setupNavbar() {
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('shadow-lg', 'bg-zinc-950/95');
            navbar.classList.remove('bg-zinc-950/80');
        } else {
            navbar.classList.add('bg-zinc-950/80');
            navbar.classList.remove('shadow-lg', 'bg-zinc-950/95');
        }
    });
}
