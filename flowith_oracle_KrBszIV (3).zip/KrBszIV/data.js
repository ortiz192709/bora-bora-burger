export const menuData =[
    {
        category: "Clásicas",
        title: "Bora Sencilla",
        description: "Carne de res 150g, queso amarillo, lechuga, tomate y aderezo de la casa.",
        price: "$110"
    },
    {
        category: "Clásicas",
        title: "Bora Doble",
        description: "Doble carne de res, doble queso, tocino crujiente y vegetales frescos.",
        price: "$145"
    },
    {
        category: "Especiales",
        title: "La Hawaiana",
        description: "Carne de res, queso asadero, piña a la parrilla, jamón y salsa teriyaki.",
        price: "$130"
    },
    {
        category: "Especiales",
        title: "Pollo Crispy",
        description: "Pechuga de pollo empanizada, ensalada de col, pepinillos y aderezo spicy.",
        price: "$125"
    },
    {
        category: "Combos",
        title: "Combo Pareja",
        description: "2 Hamburguesas sencillas + 2 Papas a la francesa + 2 Refrescos.",
        price: "$280"
    },
    {
        category: "Combos",
        title: "Combo Familiar",
        description: "4 Hamburguesas (2 sencillas, 2 dobles) + Papas grandes + Refresco 2L.",
        price: "$550"
    },
    {
        category: "Extras",
        title: "Papas Gajo",
        description: "Papas sazonadas corte gajo con aderezo a elegir.",
        price: "$55"
    },
    {
        category: "Extras",
        title: "Aros de Cebolla",
        description: "Crujientes aros de cebolla empanizados (8 piezas).",
        price: "$65"
    }
];
